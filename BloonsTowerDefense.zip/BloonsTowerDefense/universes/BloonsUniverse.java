import java.util.ArrayList;

public class BloonsUniverse implements Universe {

	private boolean complete = false;
	private ArrayList<Background> backgrounds = null;
	private Background background = null;
	private DisplayableSprite player1 = null;
	private ArrayList<DisplayableSprite> sprites = new ArrayList<DisplayableSprite>();
	private double xCenter = 0;
	private double yCenter = 0;

	public static int lives = 100;
	public static int cash = 850;
	public static int round = 1;
	public static double cashIncriment = 1.05;

	public BloonsUniverse() {

		background = new MappedBackground();
		ArrayList<DisplayableSprite> barriers = ((MappedBackground) background).getBarriers();
		backgrounds = new ArrayList<Background>();
		backgrounds.add(background);

		player1 = new PlayerTransparentSprite(MappedBackground.TILE_HEIGHT * 2, MappedBackground.TILE_WIDTH * 2,
				MappedBackground.TILE_HEIGHT * 0.9, MappedBackground.TILE_HEIGHT * 0.9);

		sprites.add(player1);
		sprites.addAll(barriers);

		int xPosition = 25;

		while (xPosition > -300) {
			sprites.add(new RedBalloonSprite(xPosition, 25));
			xPosition -= 25;
		}

//		sprites.add(new DartMonkeySprite(225, 175));
//		sprites.add(new DartMonkeySprite(325, 225));
//		sprites.add(new BananaBankSprite(325, 275));
//		sprites.add(new SniperMonkeySprite(375, 375));
//		sprites.add(new SniperMonkeySprite(325, 375));
//		sprites.add(new SniperMonkeySprite(425, 375));
//		sprites.add(new SuperMonkeySprite(125, 275));

	}

	public double getScale() {
		return 1;
	}

	public double getXCenter() {
		return this.xCenter;
	}

	public double getYCenter() {
		return this.yCenter;
	}

	public void setXCenter(double xCenter) {
		this.xCenter = xCenter;
	}

	public void setYCenter(double yCenter) {
		this.yCenter = yCenter;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		complete = true;
	}

	public ArrayList<Background> getBackgrounds() {
		return backgrounds;
	}

	public DisplayableSprite getPlayer1() {
		return player1;
	}

	public ArrayList<DisplayableSprite> getSprites() {
		return sprites;
	}

	public boolean centerOnPlayer() {
		return true;
	}

	int count = 0;
	int xPos = 25;
	int yPos = 75;

	public void update(KeyboardInput keyboard, long actual_delta_time) {

		if (keyboard.keyDownOnce(27)) {
			complete = true;
		}

		for (int i = 0; i < sprites.size(); i++) {
			DisplayableSprite sprite = sprites.get(i);
			sprite.update(this, keyboard, actual_delta_time);
		}

		if (keyboard.keyDown(49)) {
			count++;
			if (count >= 5 && cash >= 450) {
				sprites.add(new DartMonkeySprite(xPos, yPos));
				if (xPos > 450) {
					xPos = -25;
					yPos += 50;

				}
				xPos += 50;
				count = 0;
				cash -= 450;
			}

		}

		if (keyboard.keyDown(50)) {
			count++;
			if (count >= 5 && cash >= 300) {
				sprites.add(new SniperMonkeySprite(xPos, yPos));
				if (xPos > 450) {
					xPos = -25;
					yPos += 50;

				}
				xPos += 50;
				count = 0;
				cash -= 300;
			}

		}

		if (keyboard.keyDown(51)) {
			count++;
			if (count >= 5 && cash > 3000) {
				sprites.add(new SuperMonkeySprite(xPos, yPos));
				if (xPos > 450) {
					xPos = -25;
					yPos += 50;

				}
				xPos += 50;
				count = 0;
				cash -= 3000;
			}

		}

		if (keyboard.keyDown(52)) {
			count++;
			if (count >= 5 && cash >= 8000) {
				sprites.add(new BananaBankSprite(xPos, yPos));
				if (xPos > 450) {
					xPos = -25;
					yPos += 50;

				}
				xPos += 50;
				count = 0;
				cash -= 8000;
			}

		}

		if (lives <= 0) {
			System.out.println("You Lose!");
			System.exit(1);
		}

		int j = 0;
		boolean aliveBalloonFound = false;

		for (int i = 0; i < sprites.size(); i++) {
			if (sprites.get(i) instanceof RedBalloonSprite) {
				if (((RedBalloonSprite) sprites.get(i)).isAlive() == true) {
					aliveBalloonFound = true;

				}
			}
		}

		if (aliveBalloonFound == false) {

			round++;

			if (round == 2) {
				cash+=100;
				int xPosition = 25;
				while (xPosition > -500) {
					sprites.add(new RedBalloonSprite(xPosition, 25));
					xPosition -= 20;

				}

			} else if (round == 3) {
				cash+=100;
				int xPosition = 25;
				while (xPosition > -750) {
					sprites.add(new RedBalloonSprite(xPosition, 25));
					xPosition -= 15;

				}
				
			} else if (round == 4) {
				cash+=100;
				int xPosition = 25;
				while (xPosition > -500) {
					sprites.add(new RedBalloonSprite(xPosition, 25));
					xPosition -= 10;

				}

			} else if (round == 5) {
			cash+=100;
			int xPosition = 25;
			while (xPosition > -1000) {
				sprites.add(new RedBalloonSprite(xPosition, 25));
				xPosition -= 5;

			}

		} else if (round == 6) {
			cash+=100;
			System.out.println("round :" + round);
			int xPosition = 25;
			while (xPosition > -1000) {
				sprites.add(new RedBalloonSprite(xPosition, 25));
				xPosition -= 3;

			}

		}
			
		}

	}

	public String toString() {
		return "MappedUniverse";
	}

}
