import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class GreenBlimpSprite implements DisplayableSprite {

	int turns = -1;
	
	private static final double VELOCITY = 30;
	private static final int WIDTH = 250;
	private static final int HEIGHT = 125;
	private static Image image;
	private long elapsedTime = 0;
	private double centerX = 0;
	private double centerY = 0;
	private double width = 45;
	private double height = 45;
	private boolean dispose = false;

	//an example of an enumeration, which is a series of constants in a list. this restricts the potential values of a variable
	//declared with that type to only those values within the set, thereby promoting both code safety and readability
	private Direction direction = Direction.RIGHT;
	
	private enum Direction { DOWN(0), LEFT(1), UP(2), RIGHT(3);
		private int value = 0;
		private Direction(int value) {
			this.value = value; 
		} 
	};

	
	public GreenBlimpSprite(double centerX, double centerY) {

		this.centerX =centerX;
		this.centerY = centerY;	
		this.width = WIDTH;
		this.height = HEIGHT;
		
		if (image == null) {
			try {
				image = ImageIO.read(new File("res/greenBlimp.png"));
			}
			catch (IOException e) {
				System.err.println(e.toString());
			}	
		}
	}

	public Image getImage() {
		return image;
	}
	
	public boolean getVisible() {
		
		if (turns == 15 || turns == -1) {
			return false;
		}
		
		if (turns == 0) {
			return true;
			
		} 

			return true;

		}

	public double getMinX() {
		return centerX - (width / 2);
	}

	public double getMaxX() {
		return centerX + (width / 2);
	}

	public double getMinY() {
		return centerY - (height / 2);
	}

	public double getMaxY() {
		return centerY + (height / 2);
	}

	public double getHeight() {
		return height;
	}

	public double getWidth() {
		return width;
	}

	public double getCenterX() {
		return centerX;
	};

	public double getCenterY() {
		return centerY;
	};
	
	
	public boolean getDispose() {
		return dispose;
	}

	public void setDispose(boolean dispose) {
		this.dispose = dispose;
	}


	public void update(Universe universe, KeyboardInput keyboard, long actual_delta_time) {
		
		elapsedTime += actual_delta_time;
		
		if (this.centerX > -10 && turns == -1) {
			turns++;	
		}
		if ((this.centerX > 475) && turns == 0) {
			direction = Direction.DOWN;
			turns++;
		} else if ((this.centerY > 125) && turns == 1) {
			direction = Direction.LEFT;
			turns++;
		} else if ((this.centerX < 275) && turns == 2) {
			direction = Direction.DOWN;
			turns++;
		} else if ((this.centerY > 225) && turns == 3) {
			direction = Direction.LEFT;
			turns++;
		} else if ((this.centerX < 175) && turns == 4) {
			direction = Direction.UP;
			turns++;
		} else if (this.centerY < 125 && turns == 5) {
			direction = Direction.LEFT;
			turns++;
		} else if (this.centerX < 75 && turns == 6) {
			direction = Direction.DOWN;
			turns++;
		} else if (this.centerY > 325 && turns == 7) {
			direction = Direction.RIGHT;
			turns++;
		} else if (this.centerX > 375 && turns == 8) {
			direction = Direction.UP;
			turns++;
		} else if (this.centerY < 225 && turns == 9) {
			direction = Direction.RIGHT;
			turns++;
		} else if (this.centerX > 475 && turns == 10) {
			direction = Direction.DOWN;
			turns++;
		} else if (this.centerY > 425 && turns == 11) {
			direction = Direction.LEFT;
			turns++;
		} else if (this.centerX < 275 && turns == 12) {
			direction = Direction.DOWN;
			turns++;
		} else if (this.centerY > 525 && turns == 13) {
			direction = Direction.RIGHT;
			turns++;
		} else if (this.centerX > 474 && turns == 14) {
			turns++;
		} else if (this.centerX > 475 && turns == 15) {
			
		}

		switch (direction) {
		case UP:
			this.centerY -= actual_delta_time * 0.001 * VELOCITY;
			break;
		case DOWN:
			this.centerY += actual_delta_time * 0.001 * VELOCITY;
			break;
		case LEFT:
			this.centerX -= actual_delta_time * 0.001 * VELOCITY;
			break;
		case RIGHT:
			this.centerX += actual_delta_time * 0.001 * VELOCITY;
			break;
		}
	}

	public boolean isAlive() {
		return true;
	}
}
