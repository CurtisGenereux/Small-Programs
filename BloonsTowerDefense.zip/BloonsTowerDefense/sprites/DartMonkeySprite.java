
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class DartMonkeySprite implements DisplayableSprite {

	private double currentAngle = 90;
	private double ROTATION_SPEED = 200; // degrees per second
	private final static int FRAMES = 360;
	private static Image[] rotatedImages = new Image[FRAMES];
	private static boolean framesLoaded = false;

	private double centerX = 0;
	private double centerY = 0;
	private double width = 45;
	private double height = 45;
	private boolean dispose = false;
	private double velocityX = 0;
	private double velocityY = 0;
	private double reloadTime = 0;

	public DartMonkeySprite(double centerX, double centerY) {

		super();
		this.centerX = centerX;
		this.centerY = centerY;

		System.out.println(FRAMES);

		Image defaultImage = null;

		if (framesLoaded == false) {
			try {
				defaultImage = ImageIO.read(new File("res/monkey.png"));

				for (int i = 0; i < FRAMES; i++) {
					rotatedImages[i] = ImageRotator.rotate(defaultImage, i);
				}

			} catch (IOException e) {
			}
			framesLoaded = true;
		}
	}

	public Image getImage() {
		return rotatedImages[(int) currentAngle];
	}

	// DISPLAYABLE

	public boolean getVisible() {
		return true;
	}

	public double getMinX() {
		return centerX - (width / 2);
	}

	public double getMaxX() {
		return centerX + (width / 2);
	}

	public double getMinY() {
		return centerY - (height / 2);
	}

	public double getMaxY() {
		return centerY + (height / 2);
	}

	public double getHeight() {
		return height;
	}

	public double getWidth() {
		return width;
	}

	public double getCenterX() {
		return centerX;
	};

	public double getCenterY() {
		return centerY;
	};

	public boolean getDispose() {
		return dispose;
	}

	public void setDispose(boolean dispose) {
		this.dispose = dispose;
	}

	public void update(Universe universe, KeyboardInput keyboard, long actual_delta_time) {

		int frame = (int) currentAngle;

		shoot(universe);

		reloadTime -= actual_delta_time;

		ArrayList<DisplayableSprite> sprites = universe.getSprites();

		for (int i = sprites.size() - 1; i >= 0; i--) {

			DisplayableSprite sprite = sprites.get(i);
			if ( ((sprite instanceof RedBalloonSprite && ((RedBalloonSprite)sprite).isAlive())) 
					&& ((RedBalloonSprite)sprite).getVisible()) {
				
				double monkeyX = getCenterX();
				double monkeyY = getCenterY();

				double balloonX = sprite.getCenterX();
				double balloonY = sprite.getCenterY();

				double xDistance;
				double yDistance;

				xDistance = monkeyX - balloonX;
				yDistance = monkeyY - balloonY;

				double radians = Math.atan2(yDistance, xDistance);
				double degrees = ((radians * 180) / Math.PI)+5;
				double angle = (degrees + 360) % 360;

				currentAngle = angle;
			}
		}
	}

	public void shoot(Universe universe) {

		if (reloadTime <= 0) {
			
			double currentVelocity = Math.sqrt((velocityX * velocityX) + (velocityY * velocityY));
			double dartVelocity = 500;
			double ratio = (dartVelocity / currentVelocity);
			double angleInRadians = Math.toRadians(currentAngle - 180);
			double dartVelocityX = Math.cos(angleInRadians) * dartVelocity + velocityX;
			double dartVelocityY = Math.sin(angleInRadians) * dartVelocity + velocityY;
			double dartCurrentX = this.getCenterX();
			double dartCurrentY = this.getCenterY();

			DartProjectileSprite dart = new DartProjectileSprite(dartCurrentX, dartCurrentY, dartVelocityX, dartVelocityY);
			universe.getSprites().add(dart);

			reloadTime = 1000;

		}
	}

}
