package chess;

public class SoundLoader {

}
