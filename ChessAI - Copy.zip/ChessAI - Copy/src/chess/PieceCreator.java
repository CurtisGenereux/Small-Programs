package chess;

public class PieceCreator {

}
