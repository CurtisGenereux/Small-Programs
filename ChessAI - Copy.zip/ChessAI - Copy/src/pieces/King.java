package pieces;

import java.util.LinkedList;

public class King extends Piece{

	public King(int xPosition, int yPosition, String name, boolean isLightPiece, LinkedList<Piece> pieces) {
		super(xPosition, yPosition, name, isLightPiece, pieces);
		// TODO Auto-generated constructor stub
	}


}
