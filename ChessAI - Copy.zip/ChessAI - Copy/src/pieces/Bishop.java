package pieces;

import java.util.LinkedList;

import chess.Main;

public class Bishop extends Piece {

	public Bishop(int xPosition, int yPosition, String name, boolean isLightPiece, LinkedList<Piece> pieces) {
		super(xPosition, yPosition, name, isLightPiece, pieces);
		// TODO Auto-generated constructor stub
	}
	
	public void checkUniqueMoves() {
			
		LegalMove move;

		
		
		
		for (int i = originalX; i <= 7; i++) {
			if (Main.getPiece(i, i) != null) {
				if (Main.getPiece(i, i).isLightPiece != isLightPiece) {
					move = new LegalMove(i, i);
					legalMoveList.add(move);
					break;
				} else {
					break;
				}
			} else {
				move = new LegalMove(i, i);
				legalMoveList.add(move);
			}
		}
		
		
		
		updateOriginalPosition();
	}
}
