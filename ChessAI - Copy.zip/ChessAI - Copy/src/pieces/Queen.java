package pieces;

import java.util.LinkedList;

public class Queen extends Piece{

	public Queen(int xPosition, int yPosition, String name, boolean isLightPiece, LinkedList<Piece> pieces) {
		super(xPosition, yPosition, name, isLightPiece, pieces);
		// TODO Auto-generated constructor stub
	}
	
	public void checkUniqueMoves() {
		
	}

}
