
public class Examples {
	
	public static void main(String[] args)
	{
		ExamplesAnimation animation = new ExamplesAnimation();
		AnimationFrame frame = new AnimationFrame((Animation)animation);
		frame.start();
	}

}
