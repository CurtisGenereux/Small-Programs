package backgrounds;

public interface Background {

	public Tile getTile(int col, int row);
	
	public int getCol(double x);
	
	public int getRow(double y);
	
	public double getShiftX();
	
	public double getShiftY();
	
	public void setShiftX(double shiftX);

	public void setShiftY(double shiftY);
	
}
