package sprites.balloons;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import sprites.balloonGame.DisplayableSprite;

public class RedBalloonSprite extends BaseBalloon implements DisplayableSprite {

	boolean isGhost = false;
	
	public RedBalloonSprite(double centerX, double centerY) {

		this.balloonID = balloonCounter++;
		
		this.centerX =centerX;
		this.centerY = centerY;	
		this.width = WIDTH;
		this.height = HEIGHT;
		
		if (images == null) {
			try {
				images = new Image[8];
				for (int i = 0; i < 8; i++) {
					String path = String.format("res/redBalloon.png", i);
					images[i] = ImageIO.read(new File(path));
				}
			}
			catch (IOException e) {
				System.err.println(e.toString());
			}		
		}
	}
	
	//DISPLAYABLE

}
