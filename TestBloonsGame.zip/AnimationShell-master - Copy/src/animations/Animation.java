package animations;

import universes.Universe;

public interface Animation {
	
	public Universe getNextUniverse();	

}
