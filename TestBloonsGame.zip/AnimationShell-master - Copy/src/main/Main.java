package main;

import animations.Animation;
import animations.AnimationFrame;
import animations.ShellAnimation;

public class Main {
	
	public static void main(String[] args)
	{
		ShellAnimation animation = new ShellAnimation();
		AnimationFrame frame = new AnimationFrame((Animation)animation);
		frame.start();
	}

}
