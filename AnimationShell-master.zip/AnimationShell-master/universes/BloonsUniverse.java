import java.util.ArrayList;

public class BloonsUniverse implements Universe {

	private boolean complete = false;
	private ArrayList<Background> backgrounds = null;
	private Background background = null;
	private DisplayableSprite player1 = null;
	private ArrayList<DisplayableSprite> sprites = new ArrayList<DisplayableSprite>();
	private double xCenter = 0;
	private double yCenter = 0;
	public int lives = 100;
	public int cash = 650;

	public BloonsUniverse() {

		background = new MappedBackground();
		ArrayList<DisplayableSprite> barriers = ((MappedBackground) background).getBarriers();
		backgrounds = new ArrayList<Background>();
		backgrounds.add(background);

		player1 = new CollidingSprite(MappedBackground.TILE_HEIGHT * 2, MappedBackground.TILE_WIDTH * 2,
				MappedBackground.TILE_HEIGHT * 0.9, MappedBackground.TILE_HEIGHT * 0.9);

		sprites.add(player1);
		sprites.addAll(barriers);

		int xPosition = 25;
		int round = 1;

		if (round == 1) {
			while (xPosition > -300) {
				sprites.add(new RedBalloonSprite(xPosition, 25));
				xPosition = xPosition - 50;
			}
		}

		xPosition = 25;
		if (round == 2) {
			while (xPosition > -300) {
				sprites.add(new RedBalloonSprite(xPosition, 25));
				xPosition = xPosition - 25;
			}
		}

		xPosition = 25;
		if (round == 3) {
			while (xPosition > -150) {
				sprites.add(new RedBalloonSprite(xPosition, 25));
				xPosition = xPosition - 25;
			}
			xPosition -= 100;
			while (xPosition > -400) {
				sprites.add(new BlueBalloonSprite(xPosition, 25));
				xPosition = xPosition - 25;
			}
		}

		xPosition = 25;
		if (round == 4) {
			while (xPosition > -300) {
				sprites.add(new BlueBalloonSprite(xPosition, 25));
				xPosition = xPosition - 25;
			}
		}

		xPosition = 25;
		if (round == 5) {
			while (xPosition > -500) {
				sprites.add(new BlueBalloonSprite(xPosition, 25));
				xPosition = xPosition - 20;
			}
		}

		xPosition = 25;
		if (round == 6) {
			while (xPosition > -1000) {
				sprites.add(new GreenBalloonSprite(xPosition, 25));
				xPosition = xPosition - 100;
			}
		}

		xPosition = 25;
		if (round == 7) {
			while (xPosition > -1500) {
				sprites.add(new GreenBalloonSprite(xPosition, 25));
				xPosition = xPosition - 50;
			}
		}

		if (round == 8) {
			while (xPosition > -1250) {
				sprites.add(new YellowBalloonSprite(xPosition, 25));
				xPosition = xPosition - 250;
			}
		}

		if (round == 9) {
			while (xPosition > -250) {
				sprites.add(new RedBalloonSprite(xPosition, 25));
				xPosition = xPosition - 15;
			}
			while (xPosition > -500) {
				sprites.add(new BlueBalloonSprite(xPosition, 25));
				xPosition = xPosition - 15;
			}
			while (xPosition > -750) {
				sprites.add(new GreenBalloonSprite(xPosition, 25));
				xPosition = xPosition - 15;
			}
		}

		if (round == 50) {
			sprites.add(new GreenBlimpSprite(xPosition, 25));

		}

		if (round == 100) {
			sprites.add(new BlueBlimpSprite(0, 25));
			sprites.add(new RedBlimpSprite(-50, 25));
			sprites.add(new GreenBlimpSprite(-75, 25));

		}

		sprites.add(new DartMonkeySprite(225, 175));
		sprites.add(new SuperMonkeySprite(275, 275));
		sprites.add(new BananaBankSprite(325, 275));
		sprites.add(new SniperMonkeySprite(375, 375));
		sprites.add(new SniperMonkeySprite(325, 375));
		sprites.add(new SniperMonkeySprite(425, 375));
		sprites.add(new RotatingSprite(125, 275));

	}

	public double getScale() {
		return 1;
	}

	public double getXCenter() {
		return this.xCenter;
	}

	public double getYCenter() {
		return this.yCenter;
	}

	public void setXCenter(double xCenter) {
		this.xCenter = xCenter;
	}

	public void setYCenter(double yCenter) {
		this.yCenter = yCenter;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		complete = true;
	}

	public ArrayList<Background> getBackgrounds() {
		return backgrounds;
	}

	public DisplayableSprite getPlayer1() {
		return player1;
	}

	public ArrayList<DisplayableSprite> getSprites() {
		return sprites;
	}

	public boolean centerOnPlayer() {
		return true;
	}

	int count = 0;
	int xPos = 25;
	int yPos = 75;

	public void update(KeyboardInput keyboard, long actual_delta_time) {

		if (keyboard.keyDownOnce(27)) {
			complete = true;
		}

		for (int i = 0; i < sprites.size(); i++) {
			DisplayableSprite sprite = sprites.get(i);
			sprite.update(this, keyboard, actual_delta_time);
		}

		if (keyboard.keyDown(32)) {
			// round++;
		}

		if (keyboard.keyDown(10)) {
			count++;
			System.out.println(count);
			System.out.println();
			sprites.add(new RotatingSprite(xPos, yPos));
			if (xPos > 450) {
				xPos = -25;
				yPos += 50;

			}
			xPos += 50;

		}
	}

	public String toString() {
		return "MappedUniverse";
	}

}
