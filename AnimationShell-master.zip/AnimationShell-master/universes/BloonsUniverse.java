import java.util.ArrayList;

public class BloonsUniverse implements Universe {

	private boolean complete = false;
	private ArrayList<Background> backgrounds = null;
	private Background background = null;	
	private DisplayableSprite player1 = null;
	private ArrayList<DisplayableSprite> sprites = new ArrayList<DisplayableSprite>();
	private double xCenter = 0;
	private double yCenter = 0;
	
	public BloonsUniverse () {

		background = new MappedBackground();
		ArrayList<DisplayableSprite> barriers = ((MappedBackground)background).getBarriers();
		backgrounds =new ArrayList<Background>();
		backgrounds.add(background);
		
		player1 = new CollidingSprite(MappedBackground.TILE_HEIGHT * 2, MappedBackground.TILE_WIDTH * 2, MappedBackground.TILE_HEIGHT * 0.9, MappedBackground.TILE_HEIGHT * 0.9);
		
		sprites.add(player1);
		sprites.addAll(barriers);

		int num = 25;
		
		while (num > -450) {
			sprites.add(new GreenBalloonSprite(num, 25));
			num = num-25;
			
		} 
		
//		sprites.add(new RedBlimpSprite(25, 25));
//		sprites.add(new BlueBlimpSprite(25, 25));

//		sprites.add(new BlueBalloonSprite(25, 25));
//		sprites.add(new GreenBalloonSprite(25, 25));
		
		sprites.add(new DartMonkeySprite(225,175));
		sprites.add(new SuperMonkeySprite(275,275));
		sprites.add(new BananaBankSprite(325,275));
		sprites.add(new SniperMonkeySprite(375,375));
		sprites.add(new SniperMonkeySprite(325,375));
		sprites.add(new SniperMonkeySprite(425,375));
		sprites.add(new RotatingSprite(125,275));
		
	}

	public double getScale() {
		return 1;
	}	
	
	public double getXCenter() {
		return this.xCenter;
	}

	public double getYCenter() {
		return this.yCenter;
	}
	
	public void setXCenter(double xCenter) {
		this.xCenter = xCenter;
	}

	public void setYCenter(double yCenter) {
		this.yCenter = yCenter;
	}
	
	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		complete = true;
	}

	public ArrayList<Background> getBackgrounds() {
		return backgrounds;
	}	

	public DisplayableSprite getPlayer1() {
		return player1;
	}

	public ArrayList<DisplayableSprite> getSprites() {
		return sprites;
	}
		
	public boolean centerOnPlayer() {
		return true;
	}		
	
	public void update(KeyboardInput keyboard, long actual_delta_time) {

		if (keyboard.keyDownOnce(27)) {
			complete = true;
		}
		
		for (int i = 0; i < sprites.size(); i++) {
			DisplayableSprite sprite = sprites.get(i);
			sprite.update(this, keyboard, actual_delta_time);
    	} 
	}

	public String toString() {
		return "MappedUniverse";
	}	

}
