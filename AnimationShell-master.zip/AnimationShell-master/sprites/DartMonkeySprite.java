import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class DartMonkeySprite implements DisplayableSprite {

	private static Image image;
	private double centerX = 0;
	private double centerY = 0;
	private double width = 50;
	private double height = 50;
	private boolean dispose = false;
	private double reloadTime = 0;
	private double currentAngle = 0;

	private static final int WIDTH = 45;
	private static final int HEIGHT = 45;

	// PIXELS PER SECOND PER SECOND
	private double accelerationX = 0;
	private double accelerationY = 0;
	private double velocityX = 0;
	private double velocityY = 0;

	public DartMonkeySprite(double centerX, double centerY) {

		super();
		this.centerX = centerX;
		this.centerY = centerY;

		if (image == null) {
			try {
				image = ImageIO.read(new File("res/monkey.png"));
			} catch (IOException e) {
				System.err.println(e.toString());
			}
		}

		this.height = HEIGHT;
		this.width = WIDTH;

	}

	// DISPLAYABLE
	public Image getImage() {
		return image;
	}

	public boolean getVisible() {
		return true;
	}

	public double getMinX() {
		return centerX - (width / 2);
	}

	public double getMaxX() {
		return centerX + (width / 2);
	}

	public double getMinY() {
		return centerY - (height / 2);
	}

	public double getMaxY() {
		return centerY + (height / 2);
	}

	public double getHeight() {
		return height;
	}

	public double getWidth() {
		return width;
	}

	public double getCenterX() {
		return centerX;
	};

	public double getCenterY() {
		return centerY;
	};

	public void setDispose(boolean dispose) {
		this.dispose = dispose;
	}

	// Allow other objects to get / set velocity and acceleration
	public double getAccelerationX() {
		return accelerationX;
	}

	public void setAccelerationX(double accelerationX) {
		this.accelerationX = accelerationX;
	}

	public double getAccelerationY() {
		return accelerationY;
	}

	public void setAccelerationY(double accelerationY) {
		this.accelerationY = accelerationY;
	}

	public double getVelocityX() {
		return velocityX;
	}

	public void setVelocityX(double velocityX) {
		this.velocityX = velocityX;
	}

	public double getVelocityY() {
		return velocityY;
	}

	public void setVelocityY(double velocityY) {
		this.velocityY = velocityY;
	}

	@Override
	public boolean getDispose() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void update(Universe universe, KeyboardInput keyboard, long actual_delta_time) {

		if (keyboard.keyDown(32)) {
			shoot(universe);
		}

		reloadTime -= actual_delta_time;

	}

	public void shoot(Universe universe) {

		if (reloadTime <= 0) {
			double currentVelocity = Math.sqrt((velocityX * velocityX) + (velocityY * velocityY));
			double dartVelocity = 500; // + currentVelocity;
			double ratio = (dartVelocity / currentVelocity);
//			 = ratio * velocityX + velocityX;
//			double dartVelocityY = ratio * velocityY + velocityY;
			double angleInRadians = Math.toRadians(currentAngle);
			double dartVelocityX = Math.cos(angleInRadians) * dartVelocity + velocityX;
			double dartVelocityY = Math.sin(angleInRadians) * dartVelocity + velocityY;

			double dartCurrentX = this.getCenterX();
			double dartCurrentY = this.getCenterY();

			DartProjectileSprite dart = new DartProjectileSprite(dartCurrentX, dartCurrentY, dartVelocityX,
			dartVelocityY);
			universe.getSprites().add(dart);

			reloadTime = 1000;

		}
	}
}
